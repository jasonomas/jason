import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import {RegisterService} from './../_service/registerService/registerService'
import { Router } from '@angular/router';


@Component({
  selector: 'register-root',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [RegisterService]
})
export class RegisterComponent {

  successMessage: boolean;
  failMessage:boolean;
  constructor( private _registerService: RegisterService, private router: Router) {

  }

   ngOnInit() {
    this.successMessage = false;
    this.failMessage =false;
    }

  
  onSubmit(f: NgForm) {
    console.log(f.value);
    console.log(f.valid);

    var fdata = f.value;

    var data = {
        email : fdata.email,
        password :fdata.password,
        firstName: fdata.fname,
        lastName : fdata.lname,
        title: fdata.title,
        postCode:fdata.postcode,
        remember:fdata.checkbox,
        address_1:fdata.address1,
        address_2:fdata.address2,
        appartmentNumberOrName:fdata.appNoOrName,
        phone:fdata.phone,
        phoneAlt:fdata.phoneAlt
    }
    this._registerService.postdata(data).toPromise().then(newdata => {

      if(newdata.status == true) {
        this.failMessage = false;
        this.successMessage = true;
        setTimeout(function() {
          console.log('hide');
          this.successMessage = false;
          this.router.navigate(['/login']);
        }.bind(this), 2000);
      } else{
        this.successMessage = false;
        this.failMessage = true;
      }     
    }).catch(err => {
  
    })
  }

}
