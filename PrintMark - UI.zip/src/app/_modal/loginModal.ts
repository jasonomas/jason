export interface UserModal{
    Email:string;
    Password : string;
}