import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class LoginService {

  constructor(private http: HttpClient) {
  }

  login(data): Observable<any> {
    return this.http.post('http://localhost:2002/v1/user/slogin',data).map((res: Response) => {
        return res;
    });
  }


//   getCourceView(): Observable<any> {
//     return this.http.get('assets/data/course_view_data.json').map((res: Response) => {
//       return res;
//     });
//   }
}
