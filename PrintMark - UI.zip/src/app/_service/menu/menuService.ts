import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { environment } from '../../../environments/environment';


@Injectable()
export class MenuService {
 
  constructor(private http: HttpClient) {
  }

  menuList(): Observable<any> {
    return this.http.get('http://localhost:2002/v1/menu/menulist').map((res: Response) => {
        return res;
    });
  }

}
