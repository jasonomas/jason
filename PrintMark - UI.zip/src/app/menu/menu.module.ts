import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { MenuRoutingModule } from './menu-routing.module';
import { MenuComponent } from './menu.component';
import { FormsModule } from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule, MatMenuModule} from '@angular/material';


@NgModule({
  declarations: [
    MenuComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    MenuRoutingModule,
    MatButtonModule,
    MatMenuModule

  ],
  providers: [],
  bootstrap: [MenuComponent]
})
export class MenuModule { }
