import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MenuService } from '../_service/menu/menuService'

@Component({
  selector: 'menu-root',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
  providers: [MenuService]
})
export class MenuComponent {
  MenuList = [];
  constructor(private _menuService: MenuService, private router: Router) { 
  }

  ngOnInit() {
    this.listOfMenu();
  }

  listOfMenu() {
    this._menuService.menuList().toPromise().then(newdata => {
      if (newdata.status == true) {
        this.MenuList = newdata.data;
          console.log(this.MenuList)
      } else {

      }
    }).catch(err => {

    })
  }
  onClick(data){
    var path = data.Path;
    this.router.navigate(['/'+ path]);
  }
}