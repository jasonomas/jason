import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../_service/loginService/loginService'

@Component({
  selector: 'app-root',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService]
})
export class LoginComponent {
  successMessage: boolean;
  failMessage: boolean;
  constructor(private _loginService: LoginService) { }

  ngOnInit() {
    this.successMessage = false;
    this.failMessage = false;
  }

  onSubmit(f: NgForm) {
    var Form_data = f.value;
    var data = {
      email: Form_data.email,
      password: Form_data.password
    }

    this._loginService.login(data).toPromise().then(newdata => {

      if (newdata.status == true) {
        this.failMessage = false;
        this.successMessage = true;
        localStorage.setItem('dataSource',JSON.stringify(newdata));
        setTimeout(function () {
          console.log('hide');
          this.successMessage = false;
          this.router.navigate(['/#']);
        }.bind(this), 2000);
      } else {
        this.successMessage = false;
        this.failMessage = true;
      }
    }).catch(err => {
      this.failMessage = true;
    })
  }
}